(() => {
 const urls = new Set();
 const database = new Promise(resolve => {
  if (!window.indexedDB) return resolve(null);
  const request = indexedDB.open('acite-author-covers', 1);
  request.onupgradeneeded = () => request.result.createObjectStore('covers', { keyPath: 'id' });
  request.onsuccess = () => resolve(request.result);
  request.onerror = request.onblocked = () => resolve(null);
 });
 const loaded = database.then(db => db ? new Promise(resolve => {
  const request = db.transaction('covers').objectStore('covers').getAll();
  request.onsuccess = () => resolve(request.result);
  request.onerror = () => resolve([]);
 }) : []);
 document.querySelectorAll('.timeline-card').forEach(async profile => {
  const author = 'investigacao-' + profile.id;
  const name = profile.querySelector('.author-name').textContent.trim();
  const grid = profile.querySelector('[data-works-grid]');
  const status = profile.querySelector('[data-works-status]');
  const covers = (await loaded).filter(cover => cover.author === author).slice(0, 2);
  for (let index = 0; index < 2; index++) {
   let cover = covers[index] || { id: author + '-slot-' + index, author };
   const card = document.createElement('div');
   card.className = 'work-cover-card';
   card.innerHTML = '<button class="investigation-cover" type="button"><i class="fa-solid fa-image" aria-hidden="true"></i></button><input type="file" accept="image/*" hidden>';
   const button = card.querySelector('button');
   const input = card.querySelector('input');
   button.setAttribute('aria-label', `Alterar capa ${index + 1} de ${name}`);
   button.title = 'Clique para adicionar ou alterar a capa';
   let currentUrl;
   function show(blob) {
    if (currentUrl) { URL.revokeObjectURL(currentUrl); urls.delete(currentUrl); }
    currentUrl = URL.createObjectURL(blob);
    urls.add(currentUrl);
    const image = document.createElement('img');
    image.src = currentUrl;
    image.alt = cover.title || `Capa da obra de ${name}`;
    button.replaceChildren(image);
   }
   if (cover.blob instanceof Blob) show(cover.blob);
   button.addEventListener('click', () => input.click());
   input.addEventListener('change', async () => {
    const file = input.files[0];
    input.value = '';
    if (!file) return;
    if (!file.type.startsWith('image/')) { status.textContent = 'Selecione um ficheiro de imagem.'; return; }
    cover = { ...cover, blob: file, name: file.name };
    show(file);
    button.disabled = true;
    try {
     const db = await database;
     if (!db) throw new Error('Armazenamento indisponível');
     await new Promise((resolve, reject) => {
      const tx = db.transaction('covers', 'readwrite');
      tx.objectStore('covers').put(cover);
      tx.oncomplete = resolve;
      tx.onerror = tx.onabort = () => reject(tx.error);
     });
     status.textContent = 'Capa guardada neste navegador.';
    } catch { status.textContent = 'Capa alterada apenas nesta sessão. Não foi possível guardar.'; }
    finally { button.disabled = false; }
   });
   grid.append(card);
  }
 });
 window.addEventListener('beforeunload', () => urls.forEach(url => URL.revokeObjectURL(url)));
})();